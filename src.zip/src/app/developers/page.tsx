import { connectDB } from "@/lib/mongodb";
import Developer from "@/models/Developer";
import DevelopersPageClient from "./DevelopersPageClient";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Dubai Real Estate Developers | Binayah Properties",
  description: "Explore top real estate developers in the UAE. Browse projects by Emaar, Damac, Nakheel, Sobha, and 200+ more developers.",
};

export default async function DevelopersPage() {
  await connectDB();
  const developers = await Developer.find({ publishStatus: "Published" })
    .select("name slug description logoImage featuredImage projectCount")
    .sort({ projectCount: -1 })
    .lean();

  const serialized = JSON.parse(JSON.stringify(developers));
  return <DevelopersPageClient developers={serialized} />;
}
