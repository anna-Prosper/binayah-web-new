"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight, Building2, Search } from "lucide-react";
import { useState, useMemo } from "react";

interface Developer {
  _id: string;
  name: string;
  slug: string;
  description?: string;
  logoImage?: string;
  featuredImage?: string;
  projectCount?: number;
}

export default function DevelopersPageClient({ developers }: { developers: Developer[] }) {
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    if (!search.trim()) return developers;
    const q = search.toLowerCase();
    return developers.filter(d => d.name.toLowerCase().includes(q));
  }, [developers, search]);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-32 pb-20 bg-primary text-primary-foreground overflow-hidden">
        <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)", backgroundSize: "48px 48px" }} />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 relative">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <p className="text-accent font-semibold tracking-[0.4em] uppercase text-xs mb-4">UAE Real Estate</p>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
              Top <span className="italic font-light">Developers</span>
            </h1>
            <p className="text-primary-foreground/70 max-w-2xl text-lg">
              Browse {developers.length} developers building the UAE&apos;s most iconic communities and projects.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Search + Grid */}
      <section className="py-16 sm:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          {/* Search bar */}
          <div className="relative max-w-md mb-10">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search developers..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-card border border-border/50 rounded-xl text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/30 transition-all"
            />
          </div>

          {/* Developer grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filtered.map((d, i) => (
              <motion.div
                key={d._id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: Math.min(i * 0.03, 0.3) }}
              >
                <Link
                  href={`/developers/${d.slug}`}
                  className="group flex items-center gap-4 p-4 bg-card rounded-xl border border-border/50 hover:border-primary/20 hover:shadow-lg transition-all duration-300"
                >
                  {/* Logo / Initials */}
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary/10 to-accent/10 border border-border/50 flex items-center justify-center flex-shrink-0">
                    {d.logoImage ? (
                      <img src={d.logoImage} alt={d.name} className="w-10 h-10 object-contain" />
                    ) : (
                      <span className="text-lg font-black text-primary/50">
                        {d.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase()}
                      </span>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-sm text-foreground group-hover:text-primary transition-colors truncate">
                      {d.name}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {d.projectCount ? `${d.projectCount} project${d.projectCount > 1 ? "s" : ""}` : "View projects"}
                    </p>
                  </div>

                  {/* Arrow */}
                  <div className="w-7 h-7 rounded-full bg-primary/5 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all flex-shrink-0">
                    <ArrowUpRight className="h-3.5 w-3.5 text-primary" />
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-20 bg-card rounded-2xl border border-border/50">
              <Building2 className="h-10 w-10 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No developers found matching &ldquo;{search}&rdquo;</p>
            </div>
          )}
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}
