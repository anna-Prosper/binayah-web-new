import { connectDB } from "@/lib/mongodb";
import Developer from "@/models/Developer";
import Project from "@/models/Project";
import DeveloperDetailClient from "./DeveloperDetailClient";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

const CARD_FIELDS = "name slug status developerName community startingPrice completionDate shortOverview featuredImage imageGallery";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  await connectDB();
  const { slug } = await params;
  const developer = await Developer.findOne({ slug, publishStatus: "Published" }).lean();
  if (!developer) return { title: "Not Found" };
  return {
    title: (developer as any).metaTitle || `${(developer as any).name} Projects | Binayah Properties`,
    description: (developer as any).metaDescription || `Explore off-plan and ready properties by ${(developer as any).name} in the UAE.`,
  };
}

export default async function DeveloperPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  await connectDB();

  const developer = await Developer.findOne({ slug, publishStatus: "Published" }).lean();
  if (!developer) notFound();

  const projects = await Project.find({
    publishStatus: "Published",
    developerName: (developer as any).name,
  })
    .select(CARD_FIELDS)
    .sort({ createdAt: -1 })
    .lean();

  // Get unique communities for this developer
  const communities = [...new Set(projects.map((p: any) => p.community).filter(Boolean))].sort();

  const serialized = JSON.parse(JSON.stringify({ developer, projects, communities }));
  return (
    <DeveloperDetailClient
      developer={serialized.developer}
      projects={serialized.projects}
      communities={serialized.communities}
    />
  );
}
