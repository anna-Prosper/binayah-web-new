"use client";

import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import { motion } from "framer-motion";
import { ArrowLeft, Building, Building2, CalendarDays, ChevronRight, MapPin, Filter } from "lucide-react";
import Link from "next/link";
import { useState, useMemo } from "react";

interface Props {
  developer: any;
  projects: any[];
  communities: string[];
}

export default function DeveloperDetailClient({ developer, projects, communities }: Props) {
  const [activeCommunity, setActiveCommunity] = useState<string | null>(null);

  const filtered = useMemo(() => {
    if (!activeCommunity) return projects;
    return projects.filter((p: any) => p.community === activeCommunity);
  }, [projects, activeCommunity]);

  const initials = developer.name.split(" ").map((w: string) => w[0]).join("").slice(0, 2).toUpperCase();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero */}
      <section className="relative pt-32 pb-16 bg-primary text-primary-foreground overflow-hidden">
        <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)", backgroundSize: "48px 48px" }} />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 relative">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm text-primary-foreground/50 mb-8">
            <Link href="/" className="hover:text-primary-foreground transition-colors">Home</Link>
            <ChevronRight className="h-3.5 w-3.5" />
            <Link href="/developers" className="hover:text-primary-foreground transition-colors">Developers</Link>
            <ChevronRight className="h-3.5 w-3.5" />
            <span className="text-primary-foreground">{developer.name}</span>
          </div>

          <div className="flex flex-col sm:flex-row items-start gap-6">
            {/* Logo */}
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center flex-shrink-0">
              {developer.logoImage ? (
                <img src={developer.logoImage} alt={developer.name} className="w-14 h-14 sm:w-16 sm:h-16 object-contain" />
              ) : (
                <span className="text-3xl font-black text-white/60">{initials}</span>
              )}
            </div>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex-1">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-3">{developer.name}</h1>
              {developer.description && (
                <p className="text-primary-foreground/60 max-w-2xl text-sm sm:text-base leading-relaxed line-clamp-3">
                  {developer.description.replace(/<[^>]*>/g, "").slice(0, 300)}
                </p>
              )}

              {/* Stats row */}
              <div className="flex flex-wrap gap-6 mt-6">
                <div>
                  <p className="text-2xl sm:text-3xl font-bold text-accent">{projects.length}</p>
                  <p className="text-xs text-primary-foreground/50 uppercase tracking-wider">Projects</p>
                </div>
                <div>
                  <p className="text-2xl sm:text-3xl font-bold text-white">{communities.length}</p>
                  <p className="text-xs text-primary-foreground/50 uppercase tracking-wider">Communities</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Projects */}
      <section className="py-16 sm:py-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          {/* Community filter */}
          {communities.length > 1 && (
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-3">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Filter by Community</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setActiveCommunity(null)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    !activeCommunity
                      ? "bg-primary text-primary-foreground"
                      : "bg-card border border-border/50 text-muted-foreground hover:border-primary/20 hover:text-foreground"
                  }`}
                >
                  All ({projects.length})
                </button>
                {communities.map(c => {
                  const count = projects.filter((p: any) => p.community === c).length;
                  return (
                    <button
                      key={c}
                      onClick={() => setActiveCommunity(c)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        activeCommunity === c
                          ? "bg-primary text-primary-foreground"
                          : "bg-card border border-border/50 text-muted-foreground hover:border-primary/20 hover:text-foreground"
                      }`}
                    >
                      {c} ({count})
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <h2 className="text-2xl font-bold text-foreground mb-8">
            Projects by {developer.name} ({filtered.length})
          </h2>

          {filtered.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filtered.map((p: any, i: number) => (
                <motion.div key={p._id} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: Math.min(i * 0.06, 0.3) }}>
                  <Link href={`/project/${p.slug}`} className="group block bg-card rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 border border-border/50 hover:border-primary/20">
                    <div className="relative overflow-hidden aspect-[4/3]">
                      <img
                        src={p.featuredImage || p.imageGallery?.[0] || "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600"}
                        alt={p.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                        loading="lazy"
                      />
                      <span className="absolute top-3 left-3 text-[10px] font-bold px-2.5 py-1 rounded-lg bg-accent text-accent-foreground uppercase tracking-wider">
                        {p.status}
                      </span>
                    </div>
                    <div className="p-5">
                      <p className="text-xs text-muted-foreground flex items-center gap-1.5 mb-2">
                        <MapPin className="h-3 w-3" /> {p.community}
                      </p>
                      <h3 className="font-bold text-foreground mb-3 group-hover:text-primary transition-colors line-clamp-2">
                        {p.name}
                      </h3>
                      <div className="flex items-center justify-between border-t border-border pt-3">
                        <p className="text-sm font-bold text-primary">
                          {p.startingPrice
                            ? `From AED ${(p.startingPrice / 1_000_000).toFixed(1)}M`
                            : "Price on request"}
                        </p>
                        {p.completionDate && (
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <CalendarDays className="h-3 w-3" />
                            {(() => { try { const d = new Date(p.completionDate); return isNaN(d.getTime()) ? p.completionDate : d.getFullYear(); } catch { return p.completionDate; } })()}
                          </p>
                        )}
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-card rounded-2xl border border-border/50">
              <Building2 className="h-10 w-10 text-muted-foreground/30 mx-auto mb-4" />
              <p className="text-muted-foreground">No projects found.</p>
              <Link href="/developers" className="inline-flex items-center gap-2 text-primary font-semibold mt-4 hover:underline">
                <ArrowLeft className="h-4 w-4" /> Browse all developers
              </Link>
            </div>
          )}
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}
